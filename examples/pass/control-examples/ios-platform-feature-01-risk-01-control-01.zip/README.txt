Example control project placeholder.
