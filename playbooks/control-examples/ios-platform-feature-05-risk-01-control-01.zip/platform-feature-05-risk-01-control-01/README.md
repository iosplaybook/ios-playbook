# platform-feature-05-risk-01-control-01

This is a minimal SwiftUI app that stores a session token in the Keychain instead of the app container.

## Implemented Controls

- Stores the token with `SecItemAdd` instead of files or `UserDefaults`.
- Uses `kSecAttrAccessibleWhenUnlockedThisDeviceOnly` so the item is readable only while the device is unlocked and never migrates to another device through a backup.
- Clears the input field after saving so no plaintext copy remains in UI state.

Verify by inspecting the app container and confirming the token is not present in any file. The Keychain can still be read on a jailbroken device, so this control reduces exposure rather than removing it.

## Run

Open the `.xcodeproj` in Xcode 26 or later, connect your iPhone and press Run. The project is set to team `URQ5XSVB73` with automatic signing; anyone else should pick their own team under Signing & Capabilities. Each app also runs in the iOS Simulator.
