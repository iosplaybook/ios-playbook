import SwiftUI

@main
struct PlatformFeature05Risk01Control01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
