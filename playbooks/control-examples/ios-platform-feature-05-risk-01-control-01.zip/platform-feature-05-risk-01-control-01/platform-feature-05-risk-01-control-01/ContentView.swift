import Security
import SwiftUI

struct ContentView: View {
    @State private var token = ""
    @State private var status = "No token stored."

    var body: some View {
        NavigationStack {
            Form {
                Section("Session Token") {
                    SecureField("Token", text: $token)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }

                Section("Keychain") {
                    Button("Save to Keychain") {
                        status = saveToken(Data(token.utf8))
                            ? "Token saved to the Keychain. Nothing was written to the app container."
                            : "Save failed."
                        token = ""
                    }
                    .disabled(token.isEmpty)

                    Button("Read from Keychain") {
                        status = readToken() != nil ? "Token found in the Keychain." : "No token stored."
                    }

                    Button("Delete from Keychain", role: .destructive) {
                        deleteToken()
                        status = "Token deleted."
                    }

                    Text(status)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("platform-feature-05-risk-01-control-01")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

func saveToken(_ tokenData: Data) -> Bool {
    deleteToken()
    let query: [String: Any] = [
        kSecClass as String: kSecClassGenericPassword,
        kSecAttrAccount as String: "session_token",
        kSecValueData as String: tokenData,
        kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
    ]
    SecItemAdd(query as CFDictionary, nil)
    return readToken() != nil
}

func readToken() -> Data? {
    let query: [String: Any] = [
        kSecClass as String: kSecClassGenericPassword,
        kSecAttrAccount as String: "session_token",
        kSecReturnData as String: true,
        kSecMatchLimit as String: kSecMatchLimitOne
    ]
    var result: AnyObject?
    guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess else { return nil }
    return result as? Data
}

func deleteToken() {
    let query: [String: Any] = [
        kSecClass as String: kSecClassGenericPassword,
        kSecAttrAccount as String: "session_token"
    ]
    SecItemDelete(query as CFDictionary)
}
