import SwiftUI

@main
struct PlatformFeature04Risk01Control01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
