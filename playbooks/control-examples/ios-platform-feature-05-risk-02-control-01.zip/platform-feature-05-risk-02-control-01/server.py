"""Minimal backend that owns the authorisation decision. Run: python3 server.py"""
import json
import socket
from http.server import BaseHTTPRequestHandler, HTTPServer

PORT = 8765

# Session token -> entitlements. The server is the only authority.
SESSIONS = {"basic-user-token": set(), "premium-user-token": {"exportReport"}}


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        token = self.headers.get("Authorization", "").removeprefix("Bearer ")
        action = self.path.partition("action=")[2]
        allowed = action in SESSIONS.get(token, set())
        # Only release the gated data when the server's own check passes.
        body = {"allowed": allowed, "report": "Q3 revenue report" if allowed else None}
        self.send_response(200 if allowed else 403)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(body).encode())


print(f"Simulator: http://127.0.0.1:{PORT}")
print(f"Device:    http://{socket.gethostname().removesuffix('.local')}.local:{PORT}")
HTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
