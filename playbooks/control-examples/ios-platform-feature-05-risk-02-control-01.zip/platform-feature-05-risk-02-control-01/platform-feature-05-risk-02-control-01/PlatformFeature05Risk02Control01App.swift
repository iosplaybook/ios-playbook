import SwiftUI

@main
struct PlatformFeature05Risk02Control01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
