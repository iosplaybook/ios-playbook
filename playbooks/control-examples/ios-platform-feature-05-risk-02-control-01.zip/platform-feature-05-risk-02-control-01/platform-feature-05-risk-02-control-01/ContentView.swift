import SwiftUI

struct ContentView: View {
    @AppStorage("serverURL") private var serverURL = "http://127.0.0.1:8765"
    @State private var token = "basic-user-token"
    @State private var status = "Tap Export Report."

    // A client-side flag like this can be overridden in memory. It only changes what is displayed.
    private var isPremium = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Server (printed by server.py)") {
                    TextField("Server URL", text: $serverURL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                }

                Section("Session") {
                    Picker("Signed in as", selection: $token) {
                        Text("Basic user").tag("basic-user-token")
                        Text("Premium user").tag("premium-user-token")
                    }
                    LabeledContent("Client flag isPremium", value: isPremium ? "true" : "false")
                }

                Section("Sensitive Action") {
                    Button("Export Report") {
                        Task { await exportReport() }
                    }
                    Text(status)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("platform-feature-05-risk-02-control-01")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private func exportReport() async {
        let api = API(baseURL: serverURL, sessionToken: token)
        status = "Denied by server."
        do {
            // The client asks the server; it does not decide locally.
            let decision = try await api.authorize(action: .exportReport)
            guard decision.allowed else { return }
            status = "Server released: \(decision.report ?? "")"
        } catch {
            status = "Server unreachable. Start server.py and check the server URL."
        }
    }
}

enum Action: String {
    case exportReport
}

struct Decision: Decodable {
    let allowed: Bool
    let report: String?
}

struct API {
    let baseURL: String
    let sessionToken: String

    func authorize(action: Action) async throws -> Decision {
        guard let url = URL(string: "\(baseURL)/authorize?action=\(action.rawValue)") else {
            throw URLError(.badURL)
        }
        var request = URLRequest(url: url)
        request.setValue("Bearer \(sessionToken)", forHTTPHeaderField: "Authorization")
        let (data, _) = try await URLSession.shared.data(for: request)
        return try JSONDecoder().decode(Decision.self, from: data)
    }
}
