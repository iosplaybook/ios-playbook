# platform-feature-05-risk-02-control-01

This is a minimal SwiftUI app and Python backend where the server, not the app, decides whether a sensitive action is allowed.

## Starting the server

Run `python3 server.py` on your Mac. It prints two addresses:

- Simulator: `http://127.0.0.1:8765` (the app's default)
- Device: `http://<your-mac-name>.local:8765`. Enter it in the app's Server URL field and allow local network access when prompted. The iPhone must be on the same network, and the macOS firewall must allow incoming connections to Python.

## Implemented Controls

- `api.authorize(action: .exportReport)` sends the session token and requested action to the server; the app does not decide access locally.
- The server checks the action against the session's entitlements and returns the report only when its own check passes.
- The client-side `isPremium` flag only affects what is displayed. Overriding it at runtime does not unlock the report.

## Run

Open the `.xcodeproj` in Xcode 26 or later, connect your iPhone and press Run. The project is set to team `URQ5XSVB73` with automatic signing; anyone else should pick their own team under Signing & Capabilities. Each app also runs in the iOS Simulator.
