import SwiftUI

@main
struct PlatformFeature03Risk01Control01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
