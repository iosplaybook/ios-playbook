import SwiftUI

struct ContentView: View {
    @State private var username = ""
    @State private var password = ""
    @State private var status = "Sensitive field is protected."

    var body: some View {
        NavigationStack {
            Form {
                Section("Login") {
                    TextField("Username", text: $username)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.emailAddress)

                    // Critical control: SecureField masks the password in screenshots, recordings and screen sharing.
                    SecureField("Password", text: $password)
                        .textFieldStyle(.roundedBorder)
                }

                Section("Visible State") {
                    LabeledContent("Username", value: username.isEmpty ? "Empty" : username)
                    LabeledContent("Password", value: password.isEmpty ? "Empty" : "Protected")
                }

                Section("Sensitive Action") {
                    Button("Submit") {
                        status = password.isEmpty
                            ? "Password is required."
                            : "Password accepted without exposing its value."
                    }
                    .disabled(username.isEmpty)

                    Text(status)
                        .foregroundStyle(password.isEmpty ? Color.secondary : Color.green)
                }
            }
            .navigationTitle("platform-feature-03-risk-01-control-01")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
