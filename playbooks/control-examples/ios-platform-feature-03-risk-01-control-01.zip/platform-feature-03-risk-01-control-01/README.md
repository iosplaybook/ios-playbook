# platform-feature-03-risk-01-control-01

This is a minimal SwiftUI app that protects a sensitive password field during screenshots, screen recording, and screen mirroring.

## Implemented Controls

- Uses SwiftUI `SecureField` with `.textFieldStyle(.roundedBorder)` for the password field.
- Keeps the username visible while preventing the password value from being exposed.
- Avoids showing the password character count in the visible app state.

The app is intentionally small so the control is easy to inspect.

## Run

Open the `.xcodeproj` in Xcode 26 or later, connect your iPhone and press Run. The project is set to team `URQ5XSVB73` with automatic signing; anyone else should pick their own team under Signing & Capabilities. Each app also runs in the iOS Simulator.
