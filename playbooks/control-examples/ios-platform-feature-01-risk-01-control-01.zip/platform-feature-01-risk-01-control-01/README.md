# platform-feature-01-risk-01-control-01

This is a minimal SwiftUI app that moves string literals out of Swift source and into `confidential.yml`, which the Swift Confidential build plugin turns into obfuscated accessors at build time.

## Implemented Controls

- `confidential.yml` holds the demo literals (`apiKey`, `demoEmail`, `demoPassword`).
- The app reads them through the generated accessors `Secrets.$apiKey`, `Secrets.$demoEmail` and `Secrets.$demoPassword` instead of plaintext strings.
- The `swift-confidential` and `swift-confidential-plugin` packages (0.5.2) are already added, and the plugin runs on the app target.
- `confidential.yml` is in the project navigator only. It is not part of the app target's resources, so it is not copied into the app bundle.

The first time you build, Xcode asks you to trust the Swift Confidential plugin and macros. Choose Trust & Enable.

Demo sign-in: `user@example.com` / `verySecurePassword`.

After archiving, extract the IPA and run `strings` against the app binary. The values from `confidential.yml` should not appear as plaintext. Swift Confidential prevents easy static extraction but not runtime attacks such as hooking or memory dumping.

## Run

Open the `.xcodeproj` in Xcode 26 or later, connect your iPhone and press Run. The project is set to team `URQ5XSVB73` with automatic signing; anyone else should pick their own team under Signing & Capabilities. Each app also runs in the iOS Simulator.
