import SwiftUI

@main
struct PlatformFeature01Risk01Control01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
