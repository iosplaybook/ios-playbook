import SwiftUI

@main
struct PlatformFeature05Risk04Control01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
