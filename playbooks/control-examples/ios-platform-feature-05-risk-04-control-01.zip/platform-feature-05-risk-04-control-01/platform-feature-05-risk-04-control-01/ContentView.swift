import SwiftUI

struct ContentView: View {
    @State private var log: [String] = []

    var body: some View {
        NavigationStack {
            Form {
                Section("Sensitive Operation") {
                    Button("Fetch Token and Call API") {
                        log.append(callAPI())
                    }
                }

                Section("Log") {
                    ForEach(Array(log.enumerated()), id: \.offset) { _, entry in
                        Text(entry).font(.footnote)
                    }
                }
            }
            .navigationTitle("platform-feature-05-risk-04-control-01")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private func callAPI() -> String {
        // Short-lived credential: fetched per operation instead of held for the session.
        var token = fetchShortLivedToken()
        useToken(&token)
        return "Used a short-lived token, then zeroed its \(token.count) bytes."
    }
}

// Stands in for a server call that issues a token with a short expiry.
func fetchShortLivedToken() -> Data {
    Data("access-token-\(UUID().uuidString)".utf8)
}

func useToken(_ token: inout Data) {
    perform(with: token)
    // Overwrite the bytes rather than only dropping the reference.
    token.resetBytes(in: 0..<token.count)
}

func perform(with token: Data) {
    // Use the token for the request here. Do not copy it into logs, caches or UI state.
}
