# platform-feature-05-risk-04-control-01

This is a minimal SwiftUI app that limits how long a secret stays in memory.

## Implemented Controls

- Fetches a short-lived token per operation instead of holding one for the whole session.
- Keeps the token in a mutable `Data` buffer and overwrites it with `resetBytes(in:)` as soon as the operation completes.
- Does not copy the token into logs, caches or UI state.

A value is still recoverable while it is in use, so this control reduces the exposure window rather than removing it.

## Run

Open the `.xcodeproj` in Xcode 26 or later, connect your iPhone and press Run. The project is set to team `URQ5XSVB73` with automatic signing; anyone else should pick their own team under Signing & Capabilities. Each app also runs in the iOS Simulator.
