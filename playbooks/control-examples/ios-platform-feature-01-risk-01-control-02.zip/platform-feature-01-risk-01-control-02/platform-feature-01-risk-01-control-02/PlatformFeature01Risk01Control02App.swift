import SwiftUI

@main
struct PlatformFeature01Risk01Control02App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
