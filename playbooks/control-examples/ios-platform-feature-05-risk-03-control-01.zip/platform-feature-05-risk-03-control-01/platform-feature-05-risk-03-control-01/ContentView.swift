import CryptoKit
import DeviceCheck
import MachO
import SwiftUI

struct ContentView: View {
    @State private var jailbreakStatus = "Not run."
    @State private var integrityStatus = "Not run."
    @State private var attestStatus = "Not run."

    var body: some View {
        NavigationStack {
            Form {
                Section("01. Independent Jailbreak Checks") {
                    Button("Run Checks") {
                        let signals = [checkKnownPaths(), checkSandboxWrite(), checkLoadedDylibs()]
                        let suspicious = signals.contains(true)
                        jailbreakStatus = suspicious ? "Jailbreak signals detected." : "No jailbreak signals."
                    }
                    Text(jailbreakStatus).foregroundStyle(.secondary)
                }

                Section("02. Runtime Integrity") {
                    Button("Check for Instrumentation") {
                        integrityStatus = checkInstrumentation() ? "Hooking framework detected." : "No instrumentation detected."
                    }
                    Text(integrityStatus).foregroundStyle(.secondary)
                }

                Section("03. App Attest") {
                    Button("Generate Attestation") {
                        Task { attestStatus = await attest() }
                    }
                    Text(attestStatus).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("platform-feature-05-risk-03-control-01")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

// MARK: - 01. Independent jailbreak checks

func checkKnownPaths() -> Bool {
    let paths = [
        "/Applications/Cydia.app", "/Applications/Sileo.app", "/var/jb",
        "/Library/MobileSubstrate/MobileSubstrate.dylib", "/bin/bash", "/usr/sbin/sshd", "/etc/apt"
    ]
    return paths.contains { FileManager.default.fileExists(atPath: $0) }
}

func checkSandboxWrite() -> Bool {
    let path = "/private/jailbreak_test.txt"
    do {
        try "test".write(toFile: path, atomically: true, encoding: .utf8)
        try? FileManager.default.removeItem(atPath: path)
        return true
    } catch {
        return false
    }
}

func checkLoadedDylibs() -> Bool {
    let suspicious = ["substrate", "substitute", "libhooker", "ellekit", "tweakinject", "sslkillswitch"]
    return loadedImages().contains { image in suspicious.contains(where: image.contains) }
}

// MARK: - 02. Runtime integrity

func checkInstrumentation() -> Bool {
    let hooking = ["frida", "cycript", "gum-js"]
    let injected = loadedImages().contains { image in hooking.contains(where: image.contains) }
    return injected || isPortOpen(27042) // frida-server's default port
}

func loadedImages() -> [String] {
    (0..<_dyld_image_count()).compactMap { index in
        _dyld_get_image_name(index).map { String(cString: $0).lowercased() }
    }
}

func isPortOpen(_ port: UInt16) -> Bool {
    let fd = socket(AF_INET, SOCK_STREAM, 0)
    guard fd >= 0 else { return false }
    defer { close(fd) }
    var addr = sockaddr_in()
    addr.sin_family = sa_family_t(AF_INET)
    addr.sin_port = port.bigEndian
    addr.sin_addr.s_addr = inet_addr("127.0.0.1")
    return withUnsafePointer(to: &addr) {
        $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
            connect(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) == 0
        }
    }
}

// MARK: - 03. App Attest

// The attestation object and key ID must be sent to your backend, which verifies them with Apple
// and restricts sensitive actions when attestation fails or is absent (step 04).
// App Attest needs a physical device. It is not supported in the Simulator or on Corellium.
func attest() async -> String {
    let service = DCAppAttestService.shared
    guard service.isSupported else { return "App Attest is not supported on this device." }
    do {
        let keyId = try await service.generateKey()
        // In production the challenge comes from your server and is single-use.
        let challenge = Data(UUID().uuidString.utf8)
        let clientDataHash = Data(SHA256.hash(data: challenge))
        let attestation = try await service.attestKey(keyId, clientDataHash: clientDataHash)
        return "Attestation created (\(attestation.count) bytes). Send it with the key ID to your server for verification."
    } catch {
        return "Attestation failed: \(error.localizedDescription)"
    }
}
