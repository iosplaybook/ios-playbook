import SwiftUI

@main
struct PlatformFeature05Risk03Control01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
