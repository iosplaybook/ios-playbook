# platform-feature-05-risk-03-control-01

This is a minimal SwiftUI app that layers several independent jailbreak signals with App Attest.

## Implemented Controls

1. **Independent checks:** `signals = [checkKnownPaths(), checkSandboxWrite(), checkLoadedDylibs()]` checks known jailbreak paths, attempts a write outside the sandbox, and scans loaded dylibs for tweak injectors such as Substrate and ElleKit.
2. **Runtime integrity:** `checkInstrumentation()` looks for injected Frida or Cycript libraries and a frida-server listener on port 27042.
3. **App Attest:** generates an App Attest key and attestation object with `DCAppAttestService`.

The attestation object must be sent to your backend with the key ID and verified there, and the backend should restrict sensitive actions when attestation fails or is absent. Server-side verification is not included. App Attest requires a physical device and is not supported in the Simulator or on Corellium virtual devices.

## Run

Open the `.xcodeproj` in Xcode 26 or later, connect your iPhone and press Run. The project is set to team `URQ5XSVB73` with automatic signing; anyone else should pick their own team under Signing & Capabilities. Each app also runs in the iOS Simulator.
