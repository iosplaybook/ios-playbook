#!/bin/bash
#
# Tests the signing-identity control (platform-feature-01-risk-02-control-02) in two layers:
#
#   1) Decision logic — runs the SigningIdentityKit unit tests (matching Team ID is valid, a
#      different Team ID is rejected, an unreadable one fails closed, access-group parsing).
#
#   2) Signing-identity invariant — the runtime check reads the app's Team ID, which is the
#      keychain access-group prefix and equals the code signature's `TeamIdentifier`
#      (the `application-identifier` entitlement prefix). This layer reads that Team ID from a
#      signed .app with `codesign`, confirms a genuine build matches the pinned Team ID, and
#      confirms a re-signed (repackaged) copy no longer does.
#
# What it does NOT do: run the app's keychain code or its lock-out UI — those are device-runtime
# behaviours. It verifies the signal the control keys on, which is faithful because the Team ID the
# app reads at runtime is exactly the one it was signed with.
#
# Usage:
#   Scripts/test_signing_identity.sh --app <SignedApp.app> [--identity <resign-id>] [--team <TEAMID>]
#   Scripts/test_signing_identity.sh --ipa <SignedApp.ipa> [--identity <resign-id>] [--team <TEAMID>]
#
# --app / --ipa   A device-signed build to test (required for layer 2). Point it at this control's
#                 app once it has an Xcode target; any signed device build exercises the mechanism.
# --identity      Identity used to re-sign the repackaged copy (default: "-", ad-hoc = no team).
# --team          Expected Team ID. Overrides the value pinned in AppSigningIdentityGuard.swift;
#                 required if that value is still the placeholder.
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
PROJECT_NAME="platform-feature-01-risk-02-control-02"
PACKAGE_DIR="$PROJECT_ROOT/SigningIdentityKit"
GUARD_SOURCE="$PROJECT_ROOT/$PROJECT_NAME/AppSigningIdentityGuard.swift"
PLACEHOLDER="REPLACE_WITH_TEAM_ID"

APP_PATH=""; IPA_PATH=""; RESIGN_IDENTITY="-"; EXPECTED_TEAM=""
while [ $# -gt 0 ]; do
    case "$1" in
        --app) APP_PATH="$2"; shift 2 ;;
        --ipa) IPA_PATH="$2"; shift 2 ;;
        --identity) RESIGN_IDENTITY="$2"; shift 2 ;;
        --team) EXPECTED_TEAM="$2"; shift 2 ;;
        *) echo "unknown argument: $1" >&2; exit 2 ;;
    esac
done

fail() { echo "FAIL: $*" >&2; exit 1; }
note() { echo; echo "==> $*"; }

# TeamIdentifier from a signed bundle; empty string if ad-hoc / unsigned ("not set").
team_of() {
    local t
    t="$(codesign -dv --verbose=4 "$1" 2>&1 | sed -n 's/^TeamIdentifier=//p')"
    [ "$t" = "not set" ] && t=""
    printf '%s' "$t"
}

# --- Layer 1: decision logic -----------------------------------------------------------------
note "Layer 1 — SigningIdentityKit unit tests"
swift test --package-path "$PACKAGE_DIR" 2>&1 | grep -E "Test Suite 'All tests'|Executed [0-9]+ tests|error:" | tail -2

# --- Resolve the expected Team ID ------------------------------------------------------------
PINNED="$(grep -oE 'expectedTeamID[[:space:]]*=[[:space:]]*"[^"]*"' "$GUARD_SOURCE" | sed -E 's/.*"([^"]*)".*/\1/' || true)"
if [ -z "$EXPECTED_TEAM" ]; then
    if [ -n "$PINNED" ] && [ "$PINNED" != "$PLACEHOLDER" ]; then
        EXPECTED_TEAM="$PINNED"
    fi
fi

# --- Obtain the signed app -------------------------------------------------------------------
WORK="$(mktemp -d "${TMPDIR:-/tmp}/signing-identity-test.XXXXXX")"
trap 'rm -rf "$WORK"' EXIT

if [ -n "$IPA_PATH" ]; then
    [ -f "$IPA_PATH" ] || fail "IPA not found: $IPA_PATH"
    unzip -q "$IPA_PATH" -d "$WORK/extracted"
    APP_PATH="$(/bin/ls -d "$WORK/extracted/Payload/"*.app 2>/dev/null | head -1 || true)"
    [ -n "$APP_PATH" ] || fail "no Payload/*.app inside the IPA."
fi

if [ -z "$APP_PATH" ]; then
    note "Layer 2 — skipped"
    echo "No signed app supplied. Layer 1 (the control's decision logic) passed above."
    echo "To test the signing-identity invariant, pass a device-signed build:"
    echo "    Scripts/test_signing_identity.sh --app <SignedApp.app> --team <TEAMID>"
    echo "(This control has no Xcode target yet; build one that links SigningIdentityKit, or point"
    echo " --app at any signed device build to exercise the mechanism.)"
    note "RESULT: logic verified; signing-identity invariant not tested (no app supplied)."
    exit 0
fi
[ -d "$APP_PATH" ] || fail "app bundle not found: $APP_PATH"

GENUINE_TEAM="$(team_of "$APP_PATH")"
[ -n "$GENUINE_TEAM" ] || fail "the supplied app is not signed with a Team ID (ad-hoc?); supply a device-signed build."

if [ -z "$EXPECTED_TEAM" ]; then
    EXPECTED_TEAM="$GENUINE_TEAM"
    echo "note: expectedTeamID in $PROJECT_NAME is still \"$PLACEHOLDER\"; using the genuine app's"
    echo "      Team ID ($EXPECTED_TEAM) as the expected value for this run. Pin it for a real test."
fi

echo "App:      $APP_PATH"
echo "Expected: $EXPECTED_TEAM"

# --- Layer 2, Test 1: genuine build must match the expected Team ID ---------------------------
note "Layer 2 / Test 1 — genuine build should report the expected Team ID"
echo "signed Team ID: $GENUINE_TEAM"
[ "$GENUINE_TEAM" = "$EXPECTED_TEAM" ] \
    || fail "genuine app Team ID ($GENUINE_TEAM) != expected ($EXPECTED_TEAM). Pin the correct Team ID."
echo "PASS: matches the pinned Team ID (control would report VALID)."

# --- Layer 2, Test 2: repackaged (re-signed) copy must NOT match ------------------------------
note "Layer 2 / Test 2 — repackaged copy re-signed under another identity should be rejected"
REPACK="$WORK/$(basename "$APP_PATH")"
cp -R "$APP_PATH" "$REPACK"
# Re-signing is what any repackager must do; a different (or ad-hoc) identity yields a different
# Team ID. This is exactly the change the runtime keychain check detects.
codesign --force --sign "$RESIGN_IDENTITY" "$REPACK" >>"$WORK/codesign.log" 2>&1 \
    || { cat "$WORK/codesign.log" >&2; fail "re-sign failed."; }
REPACK_TEAM="$(team_of "$REPACK")"
echo "re-signed Team ID: ${REPACK_TEAM:-<none / ad-hoc>}"
[ "$REPACK_TEAM" != "$EXPECTED_TEAM" ] \
    || fail "re-signed copy still reports the expected Team ID; re-sign with a different identity."
echo "PASS: Team ID changed (control would report unexpectedSigningIdentity)."

note "RESULT: control verified — logic tests pass; genuine Team ID matches, repackaged Team ID does not."
