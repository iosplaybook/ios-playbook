import Foundation
import SigningIdentityKit

/// App-facing entry point for the signing-identity integrity control.
///
/// Pins the Apple Developer Team ID the legitimate build is signed with, and asks
/// `SigningIdentityGuard` whether the running app still reports that Team ID. A repackaged,
/// re-signed copy is signed under the attacker's own Apple account, so the Team ID read at
/// runtime differs and the check fails.
///
/// The Team ID is NOT a secret; it is only an expected value for the comparison.
enum AppSigningIdentityGuard {
    /// Your 10-character Team ID (Apple Developer → Membership, or `Application Identifier
    /// Prefix`), e.g. "ABCDE12345". The Simulator does not report a real Team ID, so the control
    /// reports failure there by design — verify on a device build.
    private static let expectedTeamID = "REPLACE_WITH_TEAM_ID"


    static func verify() -> SigningIdentityStatus {
        SigningIdentityGuard.verify(expectedTeamID: expectedTeamID)
    }
}
