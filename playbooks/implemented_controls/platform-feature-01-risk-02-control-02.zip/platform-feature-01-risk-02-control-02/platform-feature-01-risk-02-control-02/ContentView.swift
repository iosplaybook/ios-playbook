import SwiftUI
import SigningIdentityKit

@MainActor
final class AppState: ObservableObject {
    enum Stage: Equatable {
        case launching
        case locked
        case unauthenticated
        case authenticated
    }

    @Published private(set) var stage: Stage = .launching
    @Published private(set) var lastFindings: [SigningIdentityFinding] = []
    @Published private(set) var sensitiveReveal: String?

    /// Stand-in for real session state (tokens, decrypted caches, keys) that must be discarded
    /// the moment integrity can no longer be trusted.
    private var sessionToken: String?

    private let genericErrorText = "Something went wrong. Please reinstall the app from the App Store and try again."

    var userFacingMessage: String {
        switch stage {
        case .launching:
            return "Checking application integrity…"
        case .locked:
            return genericErrorText
        case .unauthenticated:
            return "Signing identity verified. Please sign in."
        case .authenticated:
            return "Signed in. Signing identity re-verified after authentication."
        }
    }

    /// Checkpoint 1: immediately at launch, before any UI is shown (invoked from the App's init).
    func runLaunchCheck() {
        let status = AppSigningIdentityGuard.verify()
        guard status.isValid else {
            handleFailure(status)
            return
        }
        lastFindings = []
        stage = .unauthenticated
    }

    /// Authenticates the user. This proof of concept runs the signing-identity check only at
    /// launch, so there is no additional check here.
    func authenticate() {
        sessionToken = UUID().uuidString
        stage = .authenticated
    }

    /// Performs the sensitive action. Access to this screen is already gated by the launch check.
    func performSensitiveAction() {
        guard let sessionToken else { return }
        sensitiveReveal = "Sensitive value released for session \(sessionToken.prefix(8))…"
    }

    func signOut() {
        clearSessionData()
        stage = .unauthenticated
    }

    // MARK: - Failure handling (mirrors the control's required response)

    private func handleFailure(_ status: SigningIdentityStatus) {
        clearSessionData()          // clear session data
        lastFindings = status.findings
        stage = .locked             // show generic error + disable sensitive functionality
    }

    private func clearSessionData() {
        sessionToken = nil
        sensitiveReveal = nil
    }
}

struct ContentView: View {
    @ObservedObject var state: AppState

    var body: some View {
        NavigationStack {
            Form {
                Section("Status") {
                    Label(state.userFacingMessage, systemImage: statusImage)
                        .foregroundStyle(statusTint)
                }

                switch state.stage {
                case .launching:
                    EmptyView()

                case .locked:
                    Section {
                        Button("Retry Integrity Check", action: state.runLaunchCheck)
                    }

                case .unauthenticated:
                    Section("Authentication") {
                        Button("Sign In", action: state.authenticate)
                            .buttonStyle(.borderedProminent)
                    }

                case .authenticated:
                    Section("Sensitive Functionality") {
                        Button("Use Sensitive Feature", action: state.performSensitiveAction)
                            .buttonStyle(.borderedProminent)
                        if let reveal = state.sensitiveReveal {
                            Text(reveal).foregroundStyle(.secondary)
                        }
                        Button("Sign Out", role: .destructive, action: state.signOut)
                    }
                }

                if !state.lastFindings.isEmpty {
                    Section("Diagnostics (build/testing only)") {
                        ForEach(state.lastFindings.indices, id: \.self) { index in
                            let finding = state.lastFindings[index]
                            VStack(alignment: .leading, spacing: 2) {
                                Text(finding.kind.rawValue).font(.footnote.bold())
                                Text(finding.detail).font(.footnote).foregroundStyle(.secondary)
                            }
                        }
                    }
                }
            }
            .navigationTitle("platform-feature-01-risk-02-control-02")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private var statusImage: String {
        switch state.stage {
        case .launching: return "hourglass"
        case .locked: return "xmark.octagon.fill"
        case .unauthenticated: return "lock.fill"
        case .authenticated: return "checkmark.seal.fill"
        }
    }

    private var statusTint: Color {
        switch state.stage {
        case .launching: return .secondary
        case .locked: return .red
        case .unauthenticated: return .orange
        case .authenticated: return .green
        }
    }
}
