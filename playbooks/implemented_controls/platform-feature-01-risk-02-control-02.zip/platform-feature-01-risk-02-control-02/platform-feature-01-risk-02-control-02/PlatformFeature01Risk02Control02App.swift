import SwiftUI

@main
struct PlatformFeature01Risk02Control02App: App {
    @StateObject private var state: AppState

    init() {
        // Checkpoint 1: run the signing-identity check immediately at launch, before any UI is
        // shown, so sensitive UI is never rendered for a repackaged build.
        let state = AppState()
        state.runLaunchCheck()
        _state = StateObject(wrappedValue: state)
    }

    var body: some Scene {
        WindowGroup {
            ContentView(state: state)
        }
    }
}
