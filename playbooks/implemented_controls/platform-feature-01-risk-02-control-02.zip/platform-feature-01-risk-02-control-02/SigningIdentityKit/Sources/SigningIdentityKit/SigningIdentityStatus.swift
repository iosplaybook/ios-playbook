import Foundation

/// One reason a signing-identity check failed, kept structured so callers can log detail while
/// showing the user only a generic message.
public struct SigningIdentityFinding: Equatable, Sendable {
    public enum Kind: String, Sendable {
        /// The signing Team ID could not be read; the check fails closed rather than passing.
        case signingInformationUnavailable
        /// A Team ID was read, but it is not the one the legitimate build is signed with.
        case unexpectedTeamID
    }

    public let kind: Kind
    public let detail: String

    public init(kind: Kind, detail: String) {
        self.kind = kind
        self.detail = detail
    }
}

public struct SigningIdentityStatus: Equatable, Sendable {
    public let isValid: Bool
    public let findings: [SigningIdentityFinding]

    public init(isValid: Bool, findings: [SigningIdentityFinding]) {
        self.isValid = isValid
        self.findings = findings
    }

    public static let valid = SigningIdentityStatus(isValid: true, findings: [])

    public static func invalid(_ findings: [SigningIdentityFinding]) -> SigningIdentityStatus {
        SigningIdentityStatus(isValid: false, findings: findings)
    }
}
