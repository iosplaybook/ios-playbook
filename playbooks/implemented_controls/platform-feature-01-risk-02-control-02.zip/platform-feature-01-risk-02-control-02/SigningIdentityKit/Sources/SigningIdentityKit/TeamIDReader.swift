import Foundation
import Security

/// Reads the Apple Developer Team ID (the "Application Identifier Prefix") that the running app
/// is signed with. Injectable so the verification logic can be unit-tested without the keychain.
public protocol TeamIDReading: Sendable {
    func currentTeamID() -> String?
}

/// Default reader, using only public APIs so it is App Store-safe.
///
/// iOS exposes no public API for an app to read its own entitlements or signing certificate
/// (`SecTask*` and the `SecCode*` code-signing APIs are macOS/SPI only). The supported workaround
/// is the keychain: an item added without an explicit access group lands in the app's default
/// group, whose name is "<TeamID>.<BundleID>". That prefix comes from the `application-identifier`
/// entitlement, which is sealed by the code signature and validated by the OS, and which an app
/// cannot claim for a team other than the one that signed it. So a repackaged app re-signed under
/// a different Apple account reads back a different Team ID here — the signal this control uses.
public struct KeychainTeamIDReader: TeamIDReading {
    private let probeTag: String

    public init(probeTag: String = "com.integrity.signing-identity-probe") {
        self.probeTag = probeTag
    }

    public func currentTeamID() -> String? {
        let base: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: probeTag,
            kSecAttrAccount as String: probeTag
        ]

        var query = base
        query[kSecReturnAttributes as String] = kCFBooleanTrue as Any
        query[kSecMatchLimit as String] = kSecMatchLimitOne

        var item: CFTypeRef?
        var status = SecItemCopyMatching(query as CFDictionary, &item)
        if status == errSecItemNotFound {
            // Create the probe item; iOS stamps it with the default access group.
            _ = SecItemAdd(base as CFDictionary, nil)
            status = SecItemCopyMatching(query as CFDictionary, &item)
        }

        guard status == errSecSuccess,
              let attributes = item as? [String: Any],
              let accessGroup = attributes[kSecAttrAccessGroup as String] as? String
        else {
            return nil
        }
        return Self.teamID(fromAccessGroup: accessGroup)
    }

    /// Extracts the Team ID (the first "."-separated component) from a keychain access group.
    /// Uses non-omitting split so a malformed leading-dot group yields nil instead of a stray
    /// component.
    static func teamID(fromAccessGroup accessGroup: String) -> String? {
        guard let first = accessGroup.split(separator: ".", omittingEmptySubsequences: false).first,
              !first.isEmpty
        else {
            return nil
        }
        return String(first)
    }
}
