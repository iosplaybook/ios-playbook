import Foundation

/// Verifies that the running app is still signed by the expected Apple Developer Team, detecting
/// repackaging that re-signs the app under a different signing identity.
///
/// This is a local, on-device check: like any such check it can ultimately be patched out on a
/// fully compromised (jailbroken) device. It raises the bar against casual repackaging and is a
/// cheap complement to a server-verified control such as App Attest.
public enum SigningIdentityGuard {
    public static func verify(
        expectedTeamID: String,
        reader: TeamIDReading = KeychainTeamIDReader()
    ) -> SigningIdentityStatus {
        guard let teamID = reader.currentTeamID(), !teamID.isEmpty else {
            // Fail closed: an unreadable Team ID is treated as a failed check, never a pass.
            return .invalid([SigningIdentityFinding(
                kind: .signingInformationUnavailable,
                detail: "Could not read the signing Team ID."
            )])
        }
        guard teamID == expectedTeamID else {
            return .invalid([SigningIdentityFinding(
                kind: .unexpectedTeamID,
                detail: "expected \(expectedTeamID), found \(teamID)"
            )])
        }
        return .valid
    }
}
