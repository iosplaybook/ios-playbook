// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "SigningIdentityKit",
    platforms: [
        .iOS(.v15),
        .macOS(.v12)
    ],
    products: [
        .library(name: "SigningIdentityKit", targets: ["SigningIdentityKit"])
    ],
    targets: [
        .target(name: "SigningIdentityKit"),
        .testTarget(name: "SigningIdentityKitTests", dependencies: ["SigningIdentityKit"])
    ]
)
