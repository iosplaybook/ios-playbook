import XCTest
@testable import SigningIdentityKit

final class TeamIDParsingTests: XCTestCase {
    func testExtractsTeamIDFromAppIdentifierGroup() {
        XCTAssertEqual(
            KeychainTeamIDReader.teamID(fromAccessGroup: "ABCDE12345.com.example.app"),
            "ABCDE12345"
        )
    }

    func testExtractsTeamIDFromSharedGroup() {
        XCTAssertEqual(
            KeychainTeamIDReader.teamID(fromAccessGroup: "ABCDE12345.group.com.example"),
            "ABCDE12345"
        )
    }

    func testEmptyGroupYieldsNil() {
        XCTAssertNil(KeychainTeamIDReader.teamID(fromAccessGroup: ""))
    }

    func testLeadingDotYieldsNil() {
        XCTAssertNil(KeychainTeamIDReader.teamID(fromAccessGroup: ".starts.with.dot"))
    }
}
