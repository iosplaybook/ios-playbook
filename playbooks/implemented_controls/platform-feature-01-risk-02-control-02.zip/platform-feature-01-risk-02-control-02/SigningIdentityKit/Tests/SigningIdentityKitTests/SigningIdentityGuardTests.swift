import XCTest
@testable import SigningIdentityKit

private struct StubReader: TeamIDReading {
    let value: String?
    func currentTeamID() -> String? { value }
}

final class SigningIdentityGuardTests: XCTestCase {
    func testMatchingTeamIDIsValid() {
        let status = SigningIdentityGuard.verify(
            expectedTeamID: "ABCDE12345",
            reader: StubReader(value: "ABCDE12345")
        )
        XCTAssertTrue(status.isValid)
        XCTAssertTrue(status.findings.isEmpty)
    }

    func testDifferentTeamIDIsRejected() {
        let status = SigningIdentityGuard.verify(
            expectedTeamID: "ABCDE12345",
            reader: StubReader(value: "ZZZZZ99999")
        )
        XCTAssertFalse(status.isValid)
        XCTAssertEqual(status.findings.map(\.kind), [.unexpectedTeamID])
    }

    func testUnavailableTeamIDFailsClosed() {
        let status = SigningIdentityGuard.verify(
            expectedTeamID: "ABCDE12345",
            reader: StubReader(value: nil)
        )
        XCTAssertFalse(status.isValid)
        XCTAssertEqual(status.findings.map(\.kind), [.signingInformationUnavailable])
    }

    func testEmptyTeamIDFailsClosed() {
        let status = SigningIdentityGuard.verify(
            expectedTeamID: "ABCDE12345",
            reader: StubReader(value: "")
        )
        XCTAssertFalse(status.isValid)
        XCTAssertEqual(status.findings.map(\.kind), [.signingInformationUnavailable])
    }
}
