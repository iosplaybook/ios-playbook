# Platform Feature 1 Risk 2 Control 2

A minimal SwiftUI app demonstrating a **signing-identity integrity control**: at runtime the app
checks that it is still signed by the **expected Apple Developer Team**, and blocks sensitive
functionality if it is not. This targets the same risk as
[`platform-feature-01-risk-02-control-01`](../platform-feature-01-risk-02-control-01) — IPA
repackaging — from a different angle.

It is the iOS-viable form of "verify the running app's signing identity". The macOS approach of
reading the code signature with `SecCodeCopySelf` / `SecCodeCopySigningInformation` /
`kSecCodeInfoCertificates` does **not** work here: those Code Signing Services APIs are macOS-only
and are absent from the iOS SDK (code using them does not compile for `iphoneos`). This control
uses a public, App Store-safe alternative instead.

## The idea

On a non-jailbroken device the OS already enforces that the app's code signature is **valid**. What
it does not enforce is that the signature is **yours**: an attacker who repackages your app must
re-sign it, and — lacking your private key — signs it under **their own** Apple Developer account,
i.e. a different **Team ID**. So the useful runtime question is not "is the signature valid?" but
"is the signing Team ID the one I expect?".

## How it works

### Reading the Team ID (`SigningIdentityKit`)

iOS exposes no public API for an app to read its own entitlements or certificate. The supported
workaround is the keychain: a keychain item added **without** an explicit access group is placed in
the app's default access group, whose name is `"<TeamID>.<BundleID>"`. That prefix comes from the
`application-identifier` entitlement, which is **sealed by the code signature** and cannot be
claimed for a team other than the one that signed the app. [`KeychainTeamIDReader`](SigningIdentityKit/Sources/SigningIdentityKit/TeamIDReader.swift)
reads that group back and takes the first `.`-separated component as the Team ID.

### Verifying (`SigningIdentityGuard`)

[`SigningIdentityGuard.verify(expectedTeamID:reader:)`](SigningIdentityKit/Sources/SigningIdentityKit/SigningIdentityGuard.swift)
compares the runtime Team ID against the expected one and returns a structured
`SigningIdentityStatus`:

- `signingInformationUnavailable` — the Team ID could not be read. The check **fails closed**
  (treated as invalid), never as a pass.
- `unexpectedTeamID` — a Team ID was read but does not match the expected one (repackaged and
  re-signed under a different identity).

The `TeamIDReading` protocol makes the reader injectable, so the comparison logic is unit-tested
without touching the keychain.

### App integration

[`AppSigningIdentityGuard`](platform-feature-01-risk-02-control-02/AppSigningIdentityGuard.swift)
pins the expected Team ID and exposes `verify()`. [`ContentView`](platform-feature-01-risk-02-control-02/ContentView.swift)
runs the check at the same three checkpoints as control-01 — **at launch**, **after
authentication**, and **before the sensitive action** — and on failure clears session data, shows a
generic error, and disables the sensitive feature.

## Configuration

Set your Team ID in [`AppSigningIdentityGuard.swift`](platform-feature-01-risk-02-control-02/AppSigningIdentityGuard.swift):

```swift
private static let expectedTeamID = "REPLACE_WITH_TEAM_ID"   // e.g. "ABCDE12345"
```

Your Team ID is the 10-character **Application Identifier Prefix** (Apple Developer → Membership).
It is **not a secret** — it is only the expected value for the comparison. Do not fetch it at
runtime from an untrusted source; pin it in code.

## Testing

The verification and parsing logic is covered by host-run unit tests (no device needed):

```sh
swift test --package-path SigningIdentityKit
```

They assert: a matching Team ID is valid; a different Team ID is rejected with `unexpectedTeamID`;
an unreadable/empty Team ID fails closed with `signingInformationUnavailable`; and the access-group
parsing extracts the Team ID correctly (including rejecting malformed groups).

To exercise the real keychain reader you must run on a **device** (see limitations). A quick manual
check: read the Team ID your build reports and confirm it equals what you pinned.

## Limitations

- **On-device check.** The checker and the checked run in the same process; on a jailbroken /
  AMFI-disabled device an attacker can hook `SecItemCopyMatching` or patch the comparison out. This
  raises the bar against casual repackaging; it is not a substitute for a server-verified control.
- **Simulator.** The Simulator does not report a real Team ID, so the control reports failure there
  by design. Verify on a device build.
- **Detects re-signing, not in-place patching.** It catches a change of signing identity
  (repackaging), not a byte-patched binary that somehow kept the same signature — on a
  non-jailbroken device the OS blocks the latter anyway. For structural/resource tamper detection
  (added files, injected dylibs, patched `__TEXT`), use the manifest control
  ([control-01](../platform-feature-01-risk-02-control-01)) alongside this one.
- **The robust complement is App Attest.** For high assurance, verify the app's identity
  (`<TeamID>.<BundleID>`) **on your server** with `DCAppAttestService`, whose trust root is Apple's
  hardware-backed CA rather than anything on the device.

## Layout

```
platform-feature-01-risk-02-control-02/
  SigningIdentityKit/                     Swift package (reusable, unit-tested)
    Sources/SigningIdentityKit/
      SigningIdentityStatus.swift         status + structured findings
      TeamIDReader.swift                  TeamIDReading protocol + KeychainTeamIDReader
      SigningIdentityGuard.swift          verify(expectedTeamID:reader:)
    Tests/SigningIdentityKitTests/        host-run tests (compare + parse, fail-closed)
  platform-feature-01-risk-02-control-02/ app sources
    AppSigningIdentityGuard.swift         pins the expected Team ID
    ContentView.swift                     checkpoints + failure response
    PlatformFeature01Risk02Control02App.swift
    Info.plist
```

An Xcode app target that links `SigningIdentityKit` is required to run this on a device; the package
and its tests build and run on their own with `swift test`.
