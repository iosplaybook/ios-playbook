import SwiftUI

@main
struct PlatformFeature02Risk01Control01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
