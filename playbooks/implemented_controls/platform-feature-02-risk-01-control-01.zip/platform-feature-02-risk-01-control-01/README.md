# platform-feature-02-risk-01-control-01

This is a minimal SwiftUI app that detects system proxy settings before allowing sensitive requests.

## Implemented Controls

- Calls `CFNetworkCopySystemProxySettings().takeRetainedValue()` to read the current system proxy dictionary.
- Checks common HTTP, HTTPS, SOCKS, and Proxy Auto-Configuration (PAC) settings, including `ProxyAutoConfigEnable` and `ProxyAutoConfigURLString`.
- Treats any nonzero proxy-enable value as active.
- Displays the detected host and port for explicit proxies, or the PAC URL when available.
- Blocks the demo sensitive request while an HTTP, HTTPS, SOCKS, or PAC proxy configuration is active.

The app is intentionally small so the control is easy to inspect.

This control detects configured system proxies. It does not prove that TLS interception is taking place and does not detect every VPN, transparent proxy, hooked network API, or custom network stack. Production apps must continue to enforce normal TLS server-trust validation independently of this check.
